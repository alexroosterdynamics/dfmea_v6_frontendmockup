'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import ProcessNode from './ProcessNode';

const CONNECTION_TYPES = {
  SERIES: 'series',
  DECISION: 'decision',
  PARALLEL: 'parallel',
  SUBSTEP: 'substep',
  ROUTE: 'route',
  CONDITION: 'condition',
};

// Grid settings - each cell is this size
const GRID = {
  CELL_WIDTH: 180,
  CELL_HEIGHT: 90,
  NODE_WIDTH: 120,
  NODE_HEIGHT: 40,
};

export default function ProcessCanvas() {
  const [nodes, setNodes] = useState([
    {
      id: 'start',
      label: 'Start',
      gridX: 3, // Start more centered
      gridY: 1,
      connections: [],
    },
  ]);
  const [edges, setEdges] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);
  const [editingEdge, setEditingEdge] = useState(null);
  const [hoveredIcon, setHoveredIcon] = useState(null);
  const canvasRef = useRef(null);
  const [canvasOffset, setCanvasOffset] = useState({ x: 50, y: 50 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState({ x: 0, y: 0 });

  // Calculate pixel position from grid position
  const gridToPixel = (gridX, gridY) => ({
    x: gridX * GRID.CELL_WIDTH,
    y: gridY * GRID.CELL_HEIGHT,
  });

  // Calculate edges from node connections
  useEffect(() => {
    const newEdges = [];
    nodes.forEach((node) => {
      node.connections.forEach((conn, idx) => {
        const targetNode = nodes.find((n) => n.id === conn.targetId);
        if (targetNode) {
          newEdges.push({
            id: `${node.id}-${conn.targetId}`,
            sourceId: node.id,
            targetId: conn.targetId,
            type: conn.type,
            label: conn.label || '',
            index: idx,
            sourceNode: node,
            targetNode: targetNode,
          });
        }
      });
    });
    setEdges(newEdges);
  }, [nodes]);

  // Push all nodes in a direction to make room
  const pushNodes = useCallback((direction, fromPos, excludeIds = []) => {
    return (prevNodes) => {
      return prevNodes.map(node => {
        if (excludeIds.includes(node.id)) return node;
        
        switch (direction) {
          case 'down':
            if (node.gridY >= fromPos) {
              return { ...node, gridY: node.gridY + 1 };
            }
            break;
          case 'up':
            if (node.gridY <= fromPos) {
              return { ...node, gridY: node.gridY - 1 };
            }
            break;
          case 'right':
            if (node.gridX >= fromPos) {
              return { ...node, gridX: node.gridX + 1 };
            }
            break;
          case 'left':
            if (node.gridX <= fromPos) {
              return { ...node, gridX: node.gridX - 1 };
            }
            break;
        }
        return node;
      });
    };
  }, []);

  const addNode = useCallback(
    (sourceNodeId, connectionType, label = 'Step') => {
      const sourceNode = nodes.find((n) => n.id === sourceNodeId);
      if (!sourceNode) return;

      const newNodeId = uuidv4();
      const existingConnections = sourceNode.connections;
      
      let gridX = sourceNode.gridX;
      let gridY = sourceNode.gridY;
      let pushDirection = null;
      let pushFrom = null;

      // Count existing connections of each type for this source
      const countByType = (type) => existingConnections.filter(c => 
        c.type === type || (type === CONNECTION_TYPES.SERIES && c.type === CONNECTION_TYPES.DECISION)
      ).length;

      switch (connectionType) {
        case CONNECTION_TYPES.ROUTE: {
          // ROUTE: Goes LEFT, stacks vertically (1, 2, 3, 4, 5...)
          // L-shape: left then down
          const routeCount = countByType(CONNECTION_TYPES.ROUTE);
          gridX = sourceNode.gridX - 2;
          gridY = sourceNode.gridY + routeCount;
          if (routeCount > 0) {
            pushDirection = 'down';
            pushFrom = gridY;
          }
          break;
        }
        case CONNECTION_TYPES.CONDITION: {
          // CONDITION: Diamond to RIGHT, target goes DOWN-RIGHT
          // L-shape: right (with diamond), then down-right to target
          const conditionCount = countByType(CONNECTION_TYPES.CONDITION);
          gridX = sourceNode.gridX + 2; // To the RIGHT (past the diamond)
          gridY = sourceNode.gridY + 1 + conditionCount; // Below
          pushDirection = 'down';
          pushFrom = gridY;
          break;
        }
        case CONNECTION_TYPES.SUBSTEP: {
          // SUBSTEP: Goes DOWN-RIGHT
          // L-shape: down then right
          const substepCount = countByType(CONNECTION_TYPES.SUBSTEP);
          gridX = sourceNode.gridX + 1;
          gridY = sourceNode.gridY + 1 + substepCount;
          pushDirection = 'down';
          pushFrom = gridY;
          break;
        }
        case CONNECTION_TYPES.SERIES: {
          // SERIES/DECISION: Goes RIGHT, stacks vertically with diamond
          const seriesCount = countByType(CONNECTION_TYPES.SERIES);
          gridX = sourceNode.gridX + 2;
          
          if (seriesCount === 0) {
            gridY = sourceNode.gridY;
          } else {
            gridY = sourceNode.gridY + seriesCount;
            pushDirection = 'down';
            pushFrom = gridY;
          }
          break;
        }
        case CONNECTION_TYPES.PARALLEL: {
          // PARALLEL: Goes straight DOWN with double lines
          const parallelCount = countByType(CONNECTION_TYPES.PARALLEL);
          gridX = sourceNode.gridX;
          gridY = sourceNode.gridY + 1 + parallelCount;
          pushDirection = 'down';
          pushFrom = gridY;
          break;
        }
      }

      // Check if adding series should convert to decision
      const existingSeriesConnections = existingConnections.filter(
        (c) => c.type === CONNECTION_TYPES.SERIES || c.type === CONNECTION_TYPES.DECISION
      );

      let actualConnectionType = connectionType;
      let connectionLabel = '';
      
      if (connectionType === CONNECTION_TYPES.SERIES && existingSeriesConnections.length > 0) {
        actualConnectionType = CONNECTION_TYPES.DECISION;
        connectionLabel = `Option ${existingSeriesConnections.length + 1}`;
      }

      const newNode = {
        id: newNodeId,
        label: label || 'Step',
        gridX,
        gridY,
        connections: [],
      };

      setNodes((prev) => {
        let updatedNodes = [...prev];
        
        // Push nodes to make room if needed
        if (pushDirection && pushFrom !== null) {
          updatedNodes = pushNodes(pushDirection, pushFrom, [sourceNodeId])(updatedNodes);
        }
        
        // Convert series to decision if needed
        if (connectionType === CONNECTION_TYPES.SERIES && existingSeriesConnections.length > 0) {
          updatedNodes = updatedNodes.map((n) => {
            if (n.id === sourceNodeId) {
              return {
                ...n,
                connections: n.connections.map((c) =>
                  c.type === CONNECTION_TYPES.SERIES
                    ? { ...c, type: CONNECTION_TYPES.DECISION, label: c.label || 'Option 1' }
                    : c
                ),
              };
            }
            return n;
          });
        }
        
        // Add connection to source node
        updatedNodes = updatedNodes.map((n) => {
          if (n.id === sourceNodeId) {
            return {
              ...n,
              connections: [
                ...n.connections,
                { targetId: newNodeId, type: actualConnectionType, label: connectionLabel },
              ],
            };
          }
          return n;
        });
        
        return [...updatedNodes, newNode];
      });

      return newNodeId;
    },
    [nodes, pushNodes]
  );

  const handleMouseMove = useCallback(
    (e) => {
      if (isPanning) {
        setCanvasOffset({
          x: e.clientX - panStart.x,
          y: e.clientY - panStart.y,
        });
      }
    },
    [isPanning, panStart]
  );

  const handleMouseUp = useCallback(() => {
    setIsPanning(false);
  }, []);

  const handleCanvasMouseDown = (e) => {
    if (e.target === canvasRef.current || e.target.classList.contains('canvas-bg')) {
      if (e.button === 1 || (e.button === 0 && e.altKey)) {
        setIsPanning(true);
        setPanStart({
          x: e.clientX - canvasOffset.x,
          y: e.clientY - canvasOffset.y,
        });
      } else {
        setSelectedNode(null);
        setEditingEdge(null);
      }
    }
  };

  const updateNodeLabel = (nodeId, newLabel) => {
    setNodes((prev) =>
      prev.map((n) => (n.id === nodeId ? { ...n, label: newLabel } : n))
    );
  };

  const updateEdgeLabel = (sourceId, targetId, newLabel) => {
    setNodes((prev) =>
      prev.map((n) => {
        if (n.id === sourceId) {
          return {
            ...n,
            connections: n.connections.map((c) =>
              c.targetId === targetId ? { ...c, label: newLabel } : c
            ),
          };
        }
        return n;
      })
    );
    setEditingEdge(null);
  };

  const deleteNode = (nodeId) => {
    if (nodeId === 'start') return;
    setNodes((prev) => {
      return prev
        .filter((n) => n.id !== nodeId)
        .map((n) => ({
          ...n,
          connections: n.connections.filter((c) => c.targetId !== nodeId),
        }));
    });
  };

  const renderEdge = (edge) => {
    const source = edge.sourceNode;
    const target = edge.targetNode;
    if (!source || !target) return null;

    const sourcePos = gridToPixel(source.gridX, source.gridY);
    const targetPos = gridToPixel(target.gridX, target.gridY);

    const nodeWidth = GRID.NODE_WIDTH;
    const nodeHeight = GRID.NODE_HEIGHT;
    const dotRadius = 4;

    let elements = [];
    const strokeColor = {
      [CONNECTION_TYPES.SERIES]: '#3b82f6',
      [CONNECTION_TYPES.DECISION]: '#f59e0b',
      [CONNECTION_TYPES.PARALLEL]: '#10b981',
      [CONNECTION_TYPES.SUBSTEP]: '#8b5cf6',
      [CONNECTION_TYPES.ROUTE]: '#f97316',
      [CONNECTION_TYPES.CONDITION]: '#06b6d4',
    }[edge.type] || '#64748b';

    switch (edge.type) {
      case CONNECTION_TYPES.SERIES: {
        // Straight horizontal line to the right
        const startX = sourcePos.x + nodeWidth;
        const startY = sourcePos.y + nodeHeight / 2;
        const endX = targetPos.x;
        const endY = targetPos.y + nodeHeight / 2;
        
        elements.push(
          <path
            key="line"
            d={`M ${startX} ${startY} L ${endX} ${endY}`}
            stroke={strokeColor}
            strokeWidth="2"
            fill="none"
            markerEnd="url(#arrowhead-blue)"
          />
        );
        break;
      }
      
      case CONNECTION_TYPES.DECISION: {
        // L-shape: right then down, with diamond at source
        const diamondX = sourcePos.x + nodeWidth + 35;
        const diamondY = sourcePos.y + nodeHeight / 2;
        const diamondSize = 16;
        
        const startX = sourcePos.x + nodeWidth;
        const startY = sourcePos.y + nodeHeight / 2;
        const endX = targetPos.x;
        const endY = targetPos.y + nodeHeight / 2;
        
        // Count which decision branch this is
        const decisionEdges = edges.filter(e => 
          e.sourceId === source.id && e.type === CONNECTION_TYPES.DECISION
        );
        const isFirst = decisionEdges.indexOf(edge) === 0 || decisionEdges.length === 0;
        
        // Line from source to diamond
        elements.push(
          <path
            key="to-diamond"
            d={`M ${startX} ${startY} L ${diamondX - diamondSize} ${diamondY}`}
            stroke={strokeColor}
            strokeWidth="2"
            fill="none"
          />
        );
        
        // Diamond (only for first decision edge)
        if (isFirst) {
          elements.push(
            <polygon
              key="diamond"
              points={`${diamondX},${diamondY - diamondSize} ${diamondX + diamondSize},${diamondY} ${diamondX},${diamondY + diamondSize} ${diamondX - diamondSize},${diamondY}`}
              fill={strokeColor}
              stroke="#b45309"
              strokeWidth="2"
            />
          );
        }
        
        // L-shape from diamond: right then down (or up) to target
        const bendX = diamondX + diamondSize + 25;
        elements.push(
          <path
            key="from-diamond"
            d={`M ${diamondX + diamondSize} ${diamondY} L ${bendX} ${diamondY} L ${bendX} ${endY} L ${endX} ${endY}`}
            stroke={strokeColor}
            strokeWidth="2"
            fill="none"
            markerEnd="url(#arrowhead-amber)"
          />
        );
        
        // Dot at the bend
        elements.push(
          <circle
            key="dot"
            cx={bendX}
            cy={endY}
            r={dotRadius}
            fill={strokeColor}
          />
        );
        
        // Label
        if (edge.label) {
          elements.push(
            <g 
              key="label"
              className="edge-label-group"
              style={{ cursor: 'pointer' }}
              onClick={(e) => {
                e.stopPropagation();
                setEditingEdge({ sourceId: edge.sourceId, targetId: edge.targetId, label: edge.label });
              }}
            >
              <rect
                x={bendX + 5}
                y={endY - 18}
                width={edge.label.length * 7 + 8}
                height={16}
                fill="rgba(15, 15, 20, 0.9)"
                rx="3"
              />
              <text
                x={bendX + 9}
                y={endY - 6}
                fill={strokeColor}
                fontSize="11"
                fontWeight="600"
              >
                {edge.label}
              </text>
            </g>
          );
        }
        break;
      }
      
      case CONNECTION_TYPES.ROUTE: {
        // L-shape: left then down
        const startX = sourcePos.x;
        const startY = sourcePos.y + nodeHeight / 2;
        const endX = targetPos.x + nodeWidth;
        const endY = targetPos.y + nodeHeight / 2;
        const bendX = startX - 35;
        
        elements.push(
          <path
            key="line"
            d={`M ${startX} ${startY} L ${bendX} ${startY} L ${bendX} ${endY} L ${endX} ${endY}`}
            stroke={strokeColor}
            strokeWidth="2"
            fill="none"
            markerEnd="url(#arrowhead-orange)"
          />
        );
        
        // Dot at the bend
        elements.push(
          <circle
            key="dot"
            cx={bendX}
            cy={endY}
            r={dotRadius}
            fill={strokeColor}
          />
        );
        break;
      }
      
      case CONNECTION_TYPES.CONDITION: {
        // Diamond to the RIGHT of source, then L-shape down-right to target
        const startX = sourcePos.x + nodeWidth;
        const startY = sourcePos.y + nodeHeight / 2;
        const endX = targetPos.x;
        const endY = targetPos.y + nodeHeight / 2;
        
        // Diamond position (to the right of source)
        const diamondX = startX + 35;
        const diamondY = startY;
        const diamondSize = 14;
        
        // Line from source to diamond
        elements.push(
          <path
            key="line-to-diamond"
            d={`M ${startX} ${startY} L ${diamondX - diamondSize} ${diamondY}`}
            stroke={strokeColor}
            strokeWidth="2"
            fill="none"
          />
        );
        
        // Diamond
        elements.push(
          <polygon
            key="diamond"
            points={`${diamondX},${diamondY - diamondSize} ${diamondX + diamondSize},${diamondY} ${diamondX},${diamondY + diamondSize} ${diamondX - diamondSize},${diamondY}`}
            fill={strokeColor}
            stroke="#0e7490"
            strokeWidth="2"
          />
        );
        elements.push(
          <text
            key="diamond-text"
            x={diamondX}
            y={diamondY + 4}
            textAnchor="middle"
            fill="white"
            fontSize="10"
            fontWeight="bold"
          >
            ?
          </text>
        );
        
        // L-shape from diamond: down then right to target
        const bendX = diamondX + diamondSize + 20;
        elements.push(
          <path
            key="line-from-diamond"
            d={`M ${diamondX + diamondSize} ${diamondY} L ${bendX} ${diamondY} L ${bendX} ${endY} L ${endX} ${endY}`}
            stroke={strokeColor}
            strokeWidth="2"
            fill="none"
            markerEnd="url(#arrowhead-cyan)"
          />
        );
        
        // Dot at bend
        elements.push(
          <circle
            key="dot"
            cx={bendX}
            cy={endY}
            r={dotRadius}
            fill={strokeColor}
          />
        );
        break;
      }
      
      case CONNECTION_TYPES.SUBSTEP: {
        // L-shape: down then right
        const startX = sourcePos.x + nodeWidth / 2;
        const startY = sourcePos.y + nodeHeight;
        const endX = targetPos.x;
        const endY = targetPos.y + nodeHeight / 2;
        const bendY = endY;
        
        elements.push(
          <path
            key="line"
            d={`M ${startX} ${startY} L ${startX} ${bendY} L ${endX} ${bendY}`}
            stroke={strokeColor}
            strokeWidth="2"
            strokeDasharray="6,4"
            fill="none"
            markerEnd="url(#arrowhead-purple)"
          />
        );
        
        // Dot at the bend
        elements.push(
          <circle
            key="dot"
            cx={startX}
            cy={bendY}
            r={dotRadius}
            fill={strokeColor}
          />
        );
        break;
      }
      
      case CONNECTION_TYPES.PARALLEL: {
        // Double vertical lines straight down
        const startX = sourcePos.x + nodeWidth / 2;
        const startY = sourcePos.y + nodeHeight;
        const endY = targetPos.y;
        const offset = 6;
        
        elements.push(
          <path
            key="line1"
            d={`M ${startX - offset} ${startY} L ${startX - offset} ${endY}`}
            stroke={strokeColor}
            strokeWidth="2"
            fill="none"
          />
        );
        elements.push(
          <path
            key="line2"
            d={`M ${startX + offset} ${startY} L ${startX + offset} ${endY}`}
            stroke={strokeColor}
            strokeWidth="2"
            fill="none"
          />
        );
        break;
      }
    }

    return <g key={edge.id}>{elements}</g>;
  };

  // Edge label editor
  const renderEdgeLabelEditor = () => {
    if (!editingEdge) return null;
    
    const edge = edges.find(e => e.sourceId === editingEdge.sourceId && e.targetId === editingEdge.targetId);
    if (!edge) return null;
    
    const source = edge.sourceNode;
    const sourcePos = gridToPixel(source.gridX, source.gridY);
    
    return (
      <div
        className="edge-label-editor"
        style={{
          position: 'absolute',
          left: canvasOffset.x + sourcePos.x + GRID.NODE_WIDTH + 100,
          top: canvasOffset.y + sourcePos.y,
          zIndex: 1000,
        }}
      >
        <input
          type="text"
          defaultValue={editingEdge.label}
          autoFocus
          onBlur={(e) => updateEdgeLabel(editingEdge.sourceId, editingEdge.targetId, e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              updateEdgeLabel(editingEdge.sourceId, editingEdge.targetId, e.target.value);
            } else if (e.key === 'Escape') {
              setEditingEdge(null);
            }
          }}
          className="edge-label-input"
        />
      </div>
    );
  };

  return (
    <div className="process-canvas-container">
      <div className="canvas-toolbar">
        <h1>Process Builder</h1>
        <div className="toolbar-legend">
          <span className="legend-item route">● Route</span>
          <span className="legend-item condition">● Condition</span>
          <span className="legend-item substep">● SubStep</span>
          <span className="legend-item series">● Series</span>
          <span className="legend-item decision">● Decision</span>
          <span className="legend-item parallel">● Parallel</span>
        </div>
      </div>
      <div
        ref={canvasRef}
        className="process-canvas canvas-bg"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onMouseDown={handleCanvasMouseDown}
      >
        <svg
          className="edges-layer"
          style={{
            transform: `translate(${canvasOffset.x}px, ${canvasOffset.y}px)`,
          }}
        >
          <defs>
            <marker id="arrowhead-blue" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#3b82f6" />
            </marker>
            <marker id="arrowhead-amber" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#f59e0b" />
            </marker>
            <marker id="arrowhead-green" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#10b981" />
            </marker>
            <marker id="arrowhead-purple" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#8b5cf6" />
            </marker>
            <marker id="arrowhead-orange" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#f97316" />
            </marker>
            <marker id="arrowhead-cyan" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#06b6d4" />
            </marker>
          </defs>
          {edges.map(renderEdge)}
        </svg>
        <div
          className="nodes-layer"
          style={{
            transform: `translate(${canvasOffset.x}px, ${canvasOffset.y}px)`,
          }}
        >
          {nodes.map((node) => {
            const pos = gridToPixel(node.gridX, node.gridY);
            return (
              <ProcessNode
                key={node.id}
                node={{ ...node, x: pos.x, y: pos.y }}
                isSelected={selectedNode === node.id}
                onSelect={() => setSelectedNode(node.id)}
                onAddConnection={(type) => addNode(node.id, type)}
                onUpdateLabel={(label) => updateNodeLabel(node.id, label)}
                onDelete={() => deleteNode(node.id)}
                onIconHover={setHoveredIcon}
                hoveredIcon={hoveredIcon}
              />
            );
          })}
        </div>
        {renderEdgeLabelEditor()}
      </div>
      <div className="canvas-instructions">
        <p>💡 Click icons around nodes to add connections • Click decision labels to edit • Alt+drag to pan</p>
      </div>
    </div>
  );
}
