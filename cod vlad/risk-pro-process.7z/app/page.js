import ProcessCanvas from './components/ProcessCanvas';

export default function Home() {
  return <ProcessCanvas />;
}
